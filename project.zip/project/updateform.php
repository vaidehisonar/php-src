<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
echo "<u>Database before update operation.</u><br>";
$sql = "SELECT * FROM studentform ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> 10'th: ". $row["T10"]. " - 12'th: ". $row["T12"]. "  - FE: " . $row["FE"]. " -SE: " . $row["SE"] . " -TE: " . $row["TE"] ." -BE: " . $row["BE"] ." -aggregate: " . $row["aggregate"] ." -QLR: " . $row["QLR"] ." -amcat: " . $row["amcat"] ."<br>";
     }
} else {
     echo "0 results";
}
$T10=$_POST['10'];
$T12=$_POST['12'];
$FE=$_POST['fe'];
$SE=$_POST['se'];
$TE=$_POST['te'];
$BE=$_POST['be'];
$aggregate=$_POST['agg'];
$QLR=$_POST['qlr'];
$amcat=$_POST['amcat'];

echo "<br>Values are $T10,$T12,$FE,$SE,$TE,$BE,$aggregate,$QLR,$amcat  <br><br>";


$sql="INSERT INTO student.studentform VALUES('$T10','$T12','$FE','$SE','$TE','$BE','$aggregate','$QLR','$amcat')";
$conn->query($sql);
echo "<br><br><u>Database after update operation</u>";

$sql = "SELECT * FROM studentform ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> 10'th: ". $row["T10"]. " - 12'th: ". $row["T12"]. "  - FE: " . $row["FE"]. " -SE: " . $row["SE"] . " -TE: " . $row["TE"] ." -BE: " . $row["BE"] ." -aggregate: " . $row["aggregate"] ." -QLR: " . $row["QLR"] ." -amcat: " . $row["amcat"] ."<br>";
     }
} else {
     echo "0 results";
}

$conn->close();
?>                                             

</body>
</html>
