<?php
 mysql_connect('localhost','root','');
 mysql_select_db('company');
 
 $sql="SELECT * FROM details";
 
 $records=mysql_query($sql);
 
 
?>

<html>

<head>
<title>
company details</title>

</head>
<body>

<table width="600" border="1" cellpadding="1" cellspacing="1">
<tr>

<th>id</th>
<th>name</th>
<th>contact</th>
<th>criateria</th>
<th>max_pkg</th>
<th>requirement</th>
</tr>


<?php
 while($employee=mysql_fetch_assoc($records))
 {
	 echo"<tr>";
	 
	 echo "<td>".$employee['id']."</td>";
	echo "<td>".$employee['name']."</td>";
	 echo "<td>".$employee['contact']."</td>";
	 echo "<td>".$employee['criateria']."</td>";
	 echo "<td>".$employee['maxpkg']."</td>";
	 echo "<td>".$employee['requirement']."</td>";
	 echo"</tr>";
	
	 
 }
?>

</body>
</html>