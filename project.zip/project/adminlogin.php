<?php

$connect= new mysqli('localhost', 'root' , '' , 'company');
if ($connect->connect_error) {
     die('Connection failed: ');
}
else{
	//echo 'connection successful';
	}
	
$username=$_POST['username'];
$password=$_POST['password'];


$sql="SELECT username FROM adminlogin WHERE username='$username' AND password='$password'";

$result=$connect->query($sql);
if($result-> num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
	 //echo "YOU HAVE SUCCESSFULLY LOGGED IN";
		header('Location:admin.html');
	}//exit();
}
else{
	
	
	echo "Login Unsuccessful";
	//exit();
}

?>