<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

echo "<u>Database before insertion operation.</u><br>";
$sql = "SELECT * FROM details ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> Company ID: ". $row["id"]. " - name: ". $row["name"]. "  - contact: " . $row["contact"]. " -criateria: " . $row["criateria"] . " -max package: ".$row["maxpkg"]. " -requirement:".$row["requirement"]."<br>";
     }
} else {
     echo "0 results";
}
$id=$_POST['id'];
$name=$_POST['name'];
$contact=$_POST['contact'];
$criateria=$_POST['criateria'];
$maxpkg=$_POST['maxpkg'];
$requirement=$_POST['requirement'];


echo "<br>Values are $id,$name,$contact,$criateria,$maxpkg,$requirement  <br><br>";


$sql="INSERT INTO company.details VALUES('$id','$name','$contact','$criateria','$maxpkg','$requirement')";
$conn->query($sql);
echo "<br><br><u>Database after insertion operation</u>";

$sql = "SELECT * FROM details ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
	echo "<br> Company ID: ". $row["id"]. " - name: ". $row["name"]. "  - contact: " . $row["contact"]. " -criateria: " . $row["criateria"] . " -Max package:" . $row["maxpkg"] . " -requirement:".$row["requirement"]."<br>";
         
	 }
} else {
     echo "0 results";
}

$conn->close();
?>                                             

</body>
</html>
