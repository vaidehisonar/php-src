<!DOCTYPE html>
<html>
<head>
<title>retrival_of_data</title>
<style>
table, th, td {
    border: 1px solid black;
     border-collapse: collapse;
	padding: 15px;
    text-align:left;
}
</style>
</head>
<body>

<?php

 if(isset($_POST['search']))
 {
	 $valueToSearch=$_POST['valueToSearch'];
	 $query="SELECT * FROM  `details` WHERE CONCACT (`id`,`name`,`contact`,`criateria`,`maxpkg`,`requirement`) LIKE '%".$valueToSearch."%'";
	  $search_result=filterTable($query);
 }
 else
 {
	 $query="SELECT * FROM `details`";
	 $search_result=filterTable($query);
 }
 
 function filterTable($query)
 {
	 $connect=mysqli_connect("localhost", "root","", "company");
	 $filter_Result=mysqli_query($connect,$query);
	 return $filter_Result;
 }
?> 
<form action="retive_data1.php" method="post">
<input type ="text" name="valueToSearch" placeholder="value To Search"><br><br>
<input type="submit" name="search" value="filter"><br><br>
<table>
<tr>
<th>ID</th>
<th>Cmpany Name</th>
<th>Contact</th>
<th>Criteria</th>
<th>Maximum Package</th>
<th>Requirement</th>
</tr>

<?php while($row=mysqli_fetch_array($search_result)):?>
<tr>
<td><?php echo $row['id'];?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['contact'];?></td>
<td><?php echo $row['criateria'];?></td>
<td><?php echo $row['maxpkg'];?></td>
<td><?php echo $row['requirement'];?></td>
</tr>
</table>
</form>
</body>
 
</html>
