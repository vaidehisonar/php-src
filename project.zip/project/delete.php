<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
echo "<u>Database before delete operation.</u><br>";
$sql = "SELECT * FROM details";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> ID: ". $row["id"]. " - name: ". $row["name"]. "  - address: " . $row["address"]. " -tenure: " . $row["tenure"] . "<br>";
     }
} else {
     echo "0 results";
}
$id=$_POST['id'];


echo "<br>Values are $id <br><br>";


$sql="DELETE FROM company.details WHERE id='$id'";

$result = $conn->query($sql);

echo "<u>Database after delete operation.</u><br>";
$sql = "SELECT * FROM details ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> ID: ". $row["id"]. " - name: ". $row["name"]. "  - address: " . $row["address"]. " -tenure: " . $row["tenure"] . "<br>";
     }
} else {
     echo "0 results";
}
$conn->close();
?>                                             

</body>
</html>
