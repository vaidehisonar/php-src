<?php

$connect= new mysqli('localhost', 'root' , '' , 'company');
if ($connect->connect_error) {
     die('Connection failed: ');
}
else{
	//echo 'connection successful';
	}
	
$username=$_POST['loginid'];
$password=$_POST['password'];


$sql="SELECT username FROM student WHERE username='$username' AND Password='$password' ";

$result=$connect->query($sql);
if($result-> num_rows>0)
{
	while($row=$result->fetch_assoc())
	{
	 //echo "YOU HAVE SUCCESSFULLY LOGGED IN";
		header('Location:student.html');
	}//exit();
}
else{
	
	
	echo "Login Unsuccessful";
	//exit();
}

?>