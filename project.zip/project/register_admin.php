<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
echo "<u>Database before insertion operation.</u><br>";
$sql = "SELECT * FROM adminlogin ";
$result = $conn->query($sql);

$id=$_POST['id'];
$name=$_POST['name'];
$username=$_POST['username'];
$password=$_POST['password'];


echo "<br>Values are $id,$name,$username  <br><br>";


$sql="INSERT INTO company.adminlogin VALUES('$id','$name','$username','$password')";
$conn->query($sql);
echo "<br><br><u>Database after insertion operation</u>";

$sql = "SELECT * FROM adminlogin";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
	echo "<br> Admin Id: ". $row["id"]. " - Admin name: ". $row["name"]. "  - Admin Username: " . $row["username"]."<br>";
			
		echo "LOGIN SUCCESSFUL....!";
	 }
} else {
     echo "0 results";
}

$conn->close();
?>                                             

</body>
</html>
