<!doctype html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
     die('Connection failed: ');
}
else{
	//echo 'connection successful';
}
echo "<u>Database before insertion operation</u><br>";
$sql = "SELECT * FROM student";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br>First Name:".$row["username"]."-Last Name:".$row["LastName"]."-MobileNo:".$row["Mobile No."]."-Branch:".$row["Branch"]."-EmailID:". $row["Email-ID"]."-Password:".$row["Password"]."-SinhgadID:".$row["SinhgadID"]."<br>";
     }
} else {
     echo "no results";
}
$fn = $_POST['firstname'];
$ln = $_POST['lastname'];
$mb = $_POST['mobile'];
$br = $_POST['branch'];
$eid = $_POST['emailid'];
$p = $_POST['password'];
$s = $_POST['sid'];
echo "<br> Values are $fn,$ln,$mb,$br,$eid,$p,$s<br>";

$sql="INSERT INTO company.student VALUES('$fn','$ln','$mb','$br','$eid','$p','$s')";
$conn->query($sql);
echo "<br><br><u>Database after insertion</u><br>";

$sql = "SELECT * FROM student";
$result = $conn->query($sql);

if($result->num_row >= 0)
{
//output data of each row
	while($row = $result->fetch_assoc()){		
         echo "<br>First Name:".$row["username"]."-Last Name:".$row["LastName"]."-MobileNo:".$row["Mobile No."]."-Branch:".$row["Branch"]."-EmailID:". $row["Email-ID"]."-Password:".$row["Password"]."-SinhgadID:".$row["sid"]."<br>";
	}
}
else{
	echo "no results";
}
$conn->close();
?>
</body>
</html>