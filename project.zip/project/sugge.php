<!DOCTYPE html>
<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}
	 
$suggestion=$_POST['suggestion'];


$sql="INSERT INTO student.sugges VALUES('$suggestion')";
$conn->query($sql);

echo "<br>Thanks for your suggestion !  <br><br>";

$conn->close();
?>                                             

</body>
</html>
